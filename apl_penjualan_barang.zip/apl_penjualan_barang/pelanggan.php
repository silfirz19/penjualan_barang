<?php
// membuat instance
$daftarPelanggan=NEW Pelanggan;
// aksi tampil data
if($_GET['aksi']=='tampil'){
// aksi untuk tampil data
$html = null;
$html .='<center><h3>Daftar Pelanggan</h3>';
$html .='<p>Berikut ini data pelanggan</p></center>';
$html .='<table class="table table-dark table-striped"><border="1" width="100%">
<thead>
<th>No.</th>
<th>Id Pelanggan</th>
<th>Nama</th>
<th>Jenis Kelamin</th>
<th>Nama Barang</th>
<th>Alamat</th>
<th>Nomer Telepon</th>
<th>Aksi</th>
</thead>
<tbody>';
// variabel $data menyimpan hasil return
$data = $daftarPelanggan->tampil();
$no=null;
if(isset($data)){
foreach($data as $barisPelanggan){
$no++;
$html .='<tr><td>'.$no.'</td>
<td>'.$barisPelanggan->id_pelanggan.'</td>
<td>'.$barisPelanggan->nama_pelanggan.'</td>
<td>'.$barisPelanggan->jk.'</td>
<td>'.$barisPelanggan->nama_barang.'</td>
<td>'.$barisPelanggan->alamat.'</td>
<td>'.$barisPelanggan->no_telp.'</td>
<td>

<a class="btn btn-outline-success"
href="index.php?file=pelanggan&aksi=edit&idpelanggan='.$barisPelanggan->id_pelanggan.'">Edit</a>
<a class="btn btn-outline-danger"
href="index.php?file=pelanggan&aksi=hapus&idpelanggan='.$barisPelanggan->id_pelanggan.'">Hapus</a>
</td>
</tr>';
}
}
$html .='</tbody>
</table>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='tambah') {
$html =null;
$html .='<h3>Form Tambah</h3>';
$html .='<p>Silahkan masukan form </p>';
$html .='<form method="POST" action="index.php?file=pelanggan&aksi=simpan">';
$html .='<p>Id Pelanggan<br/>';
$html .='<input type="text" name="txtidpelanggan" placeholder="Masukan Id Pelanggan" autofocus/></p>';
$html .='<p>Nama Lengkap<br/>';
$html .='<input type="text" name="txtNama" placeholder="Masukan Nama Lengkap" size="30" required/></p>';
$html .='<p>Jenis Kelamin<br/>';
$html .='<input type="radio" name="txtjk" value="L"> Laki-laki';
$html .='<input type="radio" name="txtjk" value="P"> Perempuan</p>';
$html .='<p>Nama Barang<br/>';
$html .='<input type="text" name="txtnamabarang" placeholder="Masukan Nama Barang" size="30" required/></p>';
$html .='<p>Alamat<br/>';
$html .='<textarea name="txtAlamat" placeholder="Masukanalamat lengkap" cols="50" rows="5" required></textarea></p>';
$html .='<p>Nomer Handphone<br/>';
$html .='<input type="text" name="txtnotelp" placeholder="Masukan Nomer Handphone" size="30" required/>,';
$html .='<p><input type="submit" name="tombolSimpan" value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='simpan') {
$data=array(
'id_pelanggan'=>$_POST['txtidpelanggan'],
'nama_pelanggan'=>$_POST['txtNama'],
'jk'=>$_POST['txtjk'],
'nama_barang'=>$_POST['txtnamabarang'],
'alamat'=>$_POST['txtAlamat'],
'no_telp'=>$_POST['txtnotelp']

);
// simpan siswa dengan menjalankan method simpan
$daftarPelanggan->simpan($data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=pelanggan&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='edit') {
// ambil data pelanggan
$pelanggan=$daftarPelanggan->detail($_GET['idpelanggan']);

 if($pelanggan->jk =='L'){
	$pilihL ='checked';
	$pilihP =null;
}
	else {
		$pilihP ='checked';
		$pilihL =null;
	}
	
$html =null;
$html .='<h3>Form Tambah</h3>';
$html .='<p>Silahkan masukan form </p>';
$html .='<form method="POST" action="index.php?file=pelanggan&aksi=update">';     
$html .='<p>Nomor Id Pelanggan<br/>';
$html .='<input type="text" name="txtidpelanggan" value="'.$pelanggan->id_pelanggan.'" placeholder="Masukan Id Pelanggan" readonly/></p>';
$html .='<p>Nama Lengkap<br/>';
$html .='<input type="text" name="txtNama" value="'.$pelanggan->nama_pelanggan.'" placeholder="Masukan Nama Lengkap" size="30" required autofocus/></p>';
$html .='<p>Jenis Kelamin<br/>';
$html .='<input type="radio" name="txtjk" value="L" '.$pilihL.'> Laki-laki';
$html .='<input type="radio" name="txtjk" value="P" '.$pilihP.'> Pepempuan</p>';
$html .='<p>Nama Barang<br/>';
$html .='<input type="text" name="txtnamabarang" value="'.$pelanggan->nama_barang.'" placeholder="Masukan Nama Barang" size="30" required autofocus/></p>';
$html .='<p>Nama Alamat<br/>';
$html .='<input type="text" name="txtAlamat" value="'.$pelanggan->alamat.'" placeholder="Masukan Alamat Lengkap" size="30" required autofocus/></p>';
$html .='<p>Nomer Handphone<br/>';
$html .='<input type="text" name="txtnotelp" value="'.$pelanggan->no_telp.'" placeholder="Masukan No Handphone" size="30" required autofocus/></p>';
$html .='<p><input type="submit" name="tombolSimpan" value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='update') {
$data=array(
'id_pelanggan'=>$_POST['txtidpelanggan'],
'nama_pelanggan'=>$_POST['txtNama'],
'jk'=>$_POST['txtjk'],
'nama_barang'=>$_POST['txtnamabarang'],
'no_telp'=>$_POST['txtnotelp'],
'alamat'=>$_POST['txtAlamat']
);
$daftarPelanggan->update($_POST['txtidpelanggan'],$data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=pelanggan&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='hapus') {
$daftarPelanggan->hapus($_GET['idpelanggan']);
echo '<meta http-equiv="refresh" content="0; url=index.php?file=pelanggan&aksi=tampil">';
}
// aksi tidak terdaftar
else {
echo '<p>Error 404 : Halaman tidak ditemukan !</p>';
}
?>
